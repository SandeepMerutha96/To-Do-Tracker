import { Component } from '@angular/core';
import { TokenService } from '../Services/Login/token.service';
import { Router } from '@angular/router';
import { GetTomorrowTasksService } from '../Services/Tomorrowtasks/get-tomorrow-tasks.service';
import { TASK } from '../ModelClass/Task';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent {
  newTaskHeading: string = '';
  constructor(private service: GetTomorrowTasksService ,private token:TokenService,private router: Router,private route:Router){}
  Tasks : TASK[]=[];
  message:string='';
  ngOnInit(): void {
    this.service.getTasks().subscribe(
      (data) => {
        this.Tasks = data;
        console.log("TomorrowTS");
        console.log(this.Tasks);
      },
      (error) => {
          if (error.error && error.error.message === "You have no tasks for this day") {
            this.message = `You have no tasks for ${new Date().toLocaleDateString()} (Today)`;
        } else {
          this.message = 'An error occurred while fetching tasks.';
        }
      }
    );
  }

  onCardClick(taskID: number) {
    // Navigate to the task details route with the taskID
    this.router.navigate(['/task', taskID]);
  }
  function openForm() {
    document.getElementById("myForm").style.display = "block";
  }
  
  function closeForm() {
    document.getElementById("myForm").style.display = "none";
  }
  

  
  log(){
    this.token.clearToken();
    this.route.navigateByUrl("/login");
  }

}

